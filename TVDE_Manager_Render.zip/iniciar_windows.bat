@echo off
title TVDE Manager
python -m pip install -r requirements.txt
python app.py
pause
